# 构建说明

这是一个仅针对微信 8.0.69（versionName 8.0.69，versionCode 3022）的 LSPosed 模块。微信版本不匹配时，模块不会安装业务 Hook。

## 环境

- JDK 17 或更高版本
- Android SDK Platform 36
- 支持 libxposed Modern API 102 的 LSPosed
- Android 8.1（API 27）或更高版本

## 构建

```bash
export JAVA_HOME=/path/to/jdk
export ANDROID_HOME=/path/to/android-sdk
./gradlew clean :app:assembleDebug
```

APK 位于 `app/build/outputs/apk/debug/`。

## 安装与启用

安装 APK 后，在 LSPosed 中启用模块，作用域只勾选 `com.tencent.mm`，然后强制停止并重新打开微信。

模块只处理他人撤回的消息；自己的撤回动作继续走微信原生流程。停用模块并重启微信即可回滚。

## 重要限制

微信内部类和方法会随版本变化。不要把本模块用于绕过平台规则、读取他人设备数据或修改服务端记录；它只改变本地客户端的显示和处理路径。
