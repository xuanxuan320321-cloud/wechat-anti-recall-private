package io.github.yylsping.wechatantirecall;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public final class MainActivity extends Activity {
    private static final String LAUNCHER_ALIAS =
            "io.github.yylsping.wechatantirecall.LauncherAlias";
    private static final int MIUI_RED = Color.rgb(255, 103, 0);
    private static final int TEXT = Color.rgb(35, 35, 35);
    private static final int SECONDARY = Color.rgb(125, 125, 125);
    private static final int BG = Color.rgb(246, 246, 246);
    private Button shortcutButton;
    private TextView hookStatus;
    private Switch enabledSwitch;
    private Switch timeSwitch;
    private static final String SETTINGS_AUTHORITY =
            "io.github.yylsping.wechatantirecall8079.debug.settings";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        setContentView(buildPage());
    }

    private View buildPage() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(20), dp(12), dp(20), dp(10));
        TextView title = text("防撤回", 25, TEXT, true);
        toolbar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1));
        TextView subtitle = text("LSPosed 模块", 13, SECONDARY, false);
        subtitle.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)));
        root.addView(toolbar);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(pad, 0, pad, dp(28));
        scroll.addView(content);

        content.addView(statusCard(), margin(0, 0, 0, 16));
        sectionLabel(content, "功能开关");
        content.addView(controlCard(), margin(0, 0, 0, 18));
        sectionLabel(content, "使用说明");
        LinearLayout guide = card();
        addRow(guide, "启用模块", "在 LSPosed 中启用“防撤回”，作用域只选择微信");
        addDivider(guide);
        addRow(guide, "重新加载", "强制停止微信后重新打开，Hook 才会生效");
        addDivider(guide);
        addRow(guide, "当前适配", "微信 8.0.79（versionCode 3200）");
        content.addView(guide, margin(0, 0, 0, 18));

        sectionLabel(content, "功能状态");
        LinearLayout feature = card();
        addFeature(feature, "保留他人撤回", "收到对方撤回时保留本地原消息", true);
        addDivider(feature);
        addFeature(feature, "保留原生流程", "自己撤回时继续使用微信原生处理", true);
        addDivider(feature);
        addFeature(feature, "本地运行", "不联网，不上传聊天内容", true);
        content.addView(feature, margin(0, 0, 0, 18));

        sectionLabel(content, "快捷方式");
        shortcutButton = new Button(this);
        shortcutButton.setTextSize(15);
        shortcutButton.setTextColor(Color.WHITE);
        shortcutButton.setAllCaps(false);
        shortcutButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        shortcutButton.setBackground(round(MIUI_RED, 14));
        shortcutButton.setPadding(dp(12), 0, dp(12), 0);
        shortcutButton.setOnClickListener(v -> toggleLauncherShortcut());
        content.addView(shortcutButton, margin(0, 0, 0, 14));
        refreshShortcutButton();

        TextView note = text("版本不匹配时模块会自动停止业务 Hook。停用模块并重启微信即可恢复原生状态。",
                12, SECONDARY, false);
        note.setGravity(Gravity.CENTER);
        content.addView(note, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private LinearLayout controlCard() {
        LinearLayout card = card();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(14), dp(14));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text("防撤回功能", 16, TEXT, true));
        hookStatus = text("等待微信加载", 13, SECONDARY, false);
        hookStatus.setPadding(0, dp(4), 0, 0);
        labels.addView(hookStatus);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        enabledSwitch = new Switch(this);
        enabledSwitch.setChecked(readEnabled());
        enabledSwitch.setOnCheckedChangeListener((button, checked) -> {
            writeEnabled(checked);
            updateHookStatus();
        });
        row.addView(enabledSwitch);
        card.addView(row);
        addDivider(card);
        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);
        timeRow.setPadding(dp(16), dp(14), dp(14), dp(14));
        LinearLayout timeLabels = new LinearLayout(this);
        timeLabels.setOrientation(LinearLayout.VERTICAL);
        timeLabels.addView(text("详细发送时间", 16, TEXT, true));
        TextView timeDetail = text("在头像上方显示 HH:mm:ss", 13, SECONDARY, false);
        timeDetail.setPadding(0, dp(4), 0, 0);
        timeLabels.addView(timeDetail);
        timeRow.addView(timeLabels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        timeSwitch = new Switch(this);
        timeSwitch.setChecked(readShowTime());
        timeSwitch.setOnCheckedChangeListener((button, checked) -> writeShowTime(checked));
        timeRow.addView(timeSwitch);
        card.addView(timeRow);
        updateHookStatus();
        return card;
    }

    private LinearLayout statusCard() {
        LinearLayout card = card();
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        TextView label = text("目标版本", 13, SECONDARY, false);
        card.addView(label);
        TextView target = text("微信 8.0.79", 22, TEXT, true);
        target.setPadding(0, dp(4), 0, 0);
        card.addView(target);
        TextView code = text("versionCode 3200 · ARM64 · Android 8.1+", 13, SECONDARY, false);
        code.setPadding(0, dp(5), 0, dp(14));
        card.addView(code);
        addDivider(card);
        TextView current = text(currentWechatText(), 14, TEXT, false);
        current.setPadding(0, dp(14), 0, 0);
        card.addView(current);
        return card;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (enabledSwitch != null) {
            enabledSwitch.setOnCheckedChangeListener(null);
            enabledSwitch.setChecked(readEnabled());
            enabledSwitch.setOnCheckedChangeListener((button, checked) -> {
                writeEnabled(checked);
                updateHookStatus();
            });
            updateHookStatus();
        }
        if (timeSwitch != null) {
            timeSwitch.setOnCheckedChangeListener(null);
            timeSwitch.setChecked(readShowTime());
            timeSwitch.setOnCheckedChangeListener((button, checked) -> writeShowTime(checked));
        }
    }

    private android.os.Bundle readState() {
        try {
            return getContentResolver().call(
                    android.net.Uri.parse("content://" + SETTINGS_AUTHORITY), "get", null, null);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private boolean readEnabled() {
        android.os.Bundle b = readState();
        return b == null || b.getBoolean("enabled", true);
    }

    private void writeEnabled(boolean enabled) {
        try {
            android.os.Bundle b = new android.os.Bundle();
            b.putBoolean("enabled", enabled);
            getContentResolver().call(android.net.Uri.parse("content://" + SETTINGS_AUTHORITY),
                    "set_enabled", null, b);
        } catch (Throwable ignored) {
        }
    }

    private boolean readShowTime() {
        android.os.Bundle b = readState();
        return b != null && b.getBoolean("show_time", false);
    }

    private void writeShowTime(boolean show) {
        try {
            android.os.Bundle b = new android.os.Bundle();
            b.putBoolean("show_time", show);
            getContentResolver().call(android.net.Uri.parse("content://" + SETTINGS_AUTHORITY),
                    "set_show_time", null, b);
        } catch (Throwable ignored) {
        }
    }

    private void updateHookStatus() {
        if (hookStatus == null) return;
        android.os.Bundle b = readState();
        boolean enabled = b == null || b.getBoolean("enabled", true);
        boolean hooked = b != null && b.getBoolean("hooked", false);
        if (!enabled) {
            hookStatus.setText("已关闭，微信将走原生流程");
            hookStatus.setTextColor(SECONDARY);
        } else if (hooked) {
            hookStatus.setText("Hook 已成功，功能运行中");
            hookStatus.setTextColor(Color.rgb(40, 160, 80));
        } else {
            hookStatus.setText("等待微信加载，打开微信后刷新");
            hookStatus.setTextColor(MIUI_RED);
        }
    }

    private String currentWechatText() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo("com.tencent.mm", 0);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                    ? info.getLongVersionCode() : info.versionCode;
            if ("8.0.79".equals(info.versionName) && code == 3200L) {
                return "● 当前微信匹配，模块可以生效";
            }
            return "● 当前微信：" + info.versionName + " (" + code + ")，版本不匹配";
        } catch (PackageManager.NameNotFoundException e) {
            return "● 未检测到微信";
        }
    }

    private void sectionLabel(LinearLayout parent, String value) {
        TextView label = text(value, 13, SECONDARY, false);
        label.setPadding(dp(4), 0, 0, dp(8));
        parent.addView(label, margin(0, 0, 0, 0));
    }

    private void addRow(LinearLayout parent, String title, String detail) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));
        row.addView(text(title, 16, TEXT, true));
        TextView d = text(detail, 13, SECONDARY, false);
        d.setPadding(0, dp(4), 0, 0);
        row.addView(d);
        parent.addView(row);
    }

    private void addFeature(LinearLayout parent, String title, String detail, boolean enabled) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(title, 16, TEXT, true));
        TextView d = text(detail, 13, SECONDARY, false);
        d.setPadding(0, dp(4), 0, 0);
        labels.addView(d);
        row.addView(labels, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView state = text(enabled ? "开启" : "关闭", 13, MIUI_RED, true);
        row.addView(state);
        parent.addView(row);
    }

    private LinearLayout card() {
        LinearLayout value = new LinearLayout(this);
        value.setOrientation(LinearLayout.VERTICAL);
        value.setBackground(round(Color.WHITE, 16));
        return value;
    }

    private void addDivider(LinearLayout parent) {
        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(238, 238, 238));
        parent.addView(divider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1));
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private LinearLayout.LayoutParams margin(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private ComponentName launcherAlias() {
        return new ComponentName(this, LAUNCHER_ALIAS);
    }

    private boolean isLauncherShortcutEnabled() {
        int state = getPackageManager().getComponentEnabledSetting(launcherAlias());
        return state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
    }

    private void toggleLauncherShortcut() {
        boolean enable = !isLauncherShortcutEnabled();
        getPackageManager().setComponentEnabledSetting(
                launcherAlias(), enable
                        ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                        : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
        refreshShortcutButton();
    }

    private void refreshShortcutButton() {
        if (shortcutButton != null) {
            shortcutButton.setText(isLauncherShortcutEnabled()
                    ? "隐藏桌面快捷方式" : "显示桌面快捷方式");
        }
    }
}
