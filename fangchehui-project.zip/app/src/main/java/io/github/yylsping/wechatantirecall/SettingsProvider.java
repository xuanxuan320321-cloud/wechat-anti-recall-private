package io.github.yylsping.wechatantirecall;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;

public final class SettingsProvider extends ContentProvider {
    private static final String PREFS = "module_state";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_HOOKED = "hooked";
    private static final String KEY_SHOW_TIME = "show_time";

    @Override public boolean onCreate() { return true; }

    @Override public Bundle call(String method, String arg, Bundle extras) {
        if (getContext() == null) return null;
        android.content.SharedPreferences p = getContext()
                .getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE);
        Bundle out = new Bundle();
        if ("get".equals(method)) {
            out.putBoolean(KEY_ENABLED, p.getBoolean(KEY_ENABLED, true));
            out.putBoolean(KEY_HOOKED, p.getBoolean(KEY_HOOKED, false));
            out.putBoolean(KEY_SHOW_TIME, p.getBoolean(KEY_SHOW_TIME, false));
        } else if ("set_show_time".equals(method)) {
            boolean show = extras != null && extras.getBoolean(KEY_SHOW_TIME, false);
            p.edit().putBoolean(KEY_SHOW_TIME, show).apply();
            out.putBoolean(KEY_ENABLED, p.getBoolean(KEY_ENABLED, true));
            out.putBoolean(KEY_HOOKED, p.getBoolean(KEY_HOOKED, false));
            out.putBoolean(KEY_SHOW_TIME, show);
        } else if ("set_enabled".equals(method)) {
            boolean enabled = extras != null && extras.getBoolean(KEY_ENABLED, true);
            p.edit().putBoolean(KEY_ENABLED, enabled).apply();
            if (!enabled) p.edit().putBoolean(KEY_HOOKED, false).apply();
            out.putBoolean(KEY_ENABLED, enabled);
            out.putBoolean(KEY_HOOKED, p.getBoolean(KEY_HOOKED, false));
            out.putBoolean(KEY_SHOW_TIME, p.getBoolean(KEY_SHOW_TIME, false));
        } else if ("set_hooked".equals(method)) {
            boolean hooked = extras != null && extras.getBoolean(KEY_HOOKED, false);
            p.edit().putBoolean(KEY_HOOKED, hooked).apply();
            out.putBoolean(KEY_ENABLED, p.getBoolean(KEY_ENABLED, true));
            out.putBoolean(KEY_HOOKED, hooked);
            out.putBoolean(KEY_SHOW_TIME, p.getBoolean(KEY_SHOW_TIME, false));
        }
        return out;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        MatrixCursor c = new MatrixCursor(new String[]{"enabled", "hooked"});
        Bundle b = call("get", null, null);
        c.addRow(new Object[]{b == null || b.getBoolean(KEY_ENABLED, true),
                b != null && b.getBoolean(KEY_HOOKED, false)});
        return c;
    }
    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/vnd.fangchehui.state"; }
    @Override public Uri insert(Uri uri, ContentValues values) { return null; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
}
