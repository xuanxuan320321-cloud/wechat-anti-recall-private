package io.github.yylsping.wechatantirecall;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.util.Log;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface.ModuleLoadedParam;
import io.github.libxposed.api.XposedModuleInterface.PackageReadyParam;

/** WeChat 8.0.79 / versionCode 2600 adapter. */
public final class WeChatAntiRecall extends XposedModule {
    private static final String TAG = "WxAntiRecall8079";
    private static final String TARGET_PACKAGE = "com.tencent.mm";
    private static final String VERSION_NAME = "8.0.79";
    private static final long VERSION_CODE = 3200L;
    private static final String SETTINGS_AUTHORITY =
            "io.github.yylsping.wechatantirecall8079.debug.settings";
    private static final Set<Long> NOTICE_IDS = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean attachInstalled = new AtomicBoolean(false);
    private volatile boolean mainProcess;

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        mainProcess = TARGET_PACKAGE.equals(param.getProcessName());
        if (mainProcess) log(Log.INFO, "module loaded in WeChat main process");
    }

    @Override
    public void onPackageReady(PackageReadyParam param) {
        if (!mainProcess || !TARGET_PACKAGE.equals(param.getPackageName())
                || !param.isFirstPackage() || !attachInstalled.compareAndSet(false, true)) return;
        try {
            Method attach = Application.class.getDeclaredMethod("attach", Context.class);
            attach.setAccessible(true);
            hook(attach)
                    .setPriority(XposedInterface.PRIORITY_HIGHEST)
                    .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .setId("wx-antirecall-8079.attach")
                    .intercept(chain -> {
                        Object result = chain.proceed();
                        installHook((Context) chain.getArg(0), param.getClassLoader());
                        return result;
                    });
        } catch (Throwable error) {
            log(Log.ERROR, "failed to hook Application.attach", error);
        }
    }

    private void installHook(Context context, ClassLoader loader) {
        try {
            PackageInfo info = context.getApplicationContext().getPackageManager()
                    .getPackageInfo(TARGET_PACKAGE, 0);
            long code = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                    ? info.getLongVersionCode() : info.versionCode;
            if (!VERSION_NAME.equals(info.versionName) || code != VERSION_CODE) {
                setHooked(context, false);
                log(Log.INFO, "unsupported WeChat version: " + info.versionName + " (" + code + ")");
                return;
            }
            Class<?> consumer = Class.forName("l41.t", false, loader);
            Class<?> envelope = Class.forName("com.tencent.mm.modelbase.p0", false, loader);
            Method revoke = findRevokeMethod(consumer, envelope);
            hook(revoke)
                    .setPriority(XposedInterface.PRIORITY_HIGHEST)
                    .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .setId("wx-antirecall-8079.revoke")
                    .intercept(chain -> {
                        try {
                            Object envelopeArg = chain.getArg(2);
                            if (!isEnabled(context)) return chain.proceed();
                            if (isIncoming(envelopeArg)) {
                                long serverId = ((Number) chain.getArg(1)).longValue();
                                if (NOTICE_IDS.add(serverId)) {
                                    insertBlockedNotice(loader, (String) chain.getArg(0), serverId);
                                }
                                log(Log.INFO, "kept incoming message and added notice, serverId=" + serverId);
                                // 8.0.79 performs the local destructive conversion in this
                                // method. Returning here leaves the original local message.
                                return null;
                            }
                        } catch (Throwable error) {
                            log(Log.ERROR, "revoke inspection failed; native handling preserved", error);
                        }
                        return chain.proceed();
                    });
            installTimeHook(context, loader);
            setHooked(context, true);
            log(Log.INFO, "installed 8.0.79 revoke hook: " + revoke);
        } catch (Throwable error) {
            setHooked(context, false);
            log(Log.ERROR, "8.0.79 hook installation failed", error);
        }
    }

    private static void insertBlockedNotice(ClassLoader loader, String talker, long serverId) {
        try {
            Class<?> e9Class = Class.forName("com.tencent.mm.storage.e9", false, loader);
            Class<?> c4Class = Class.forName("po3.c4", false, loader);
            Class<?> i1Class = Class.forName("pp0.i1", false, loader);
            Object service = null;
            for (Method m : i1Class.getDeclaredMethods()) {
                if (java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && "v".equals(m.getName()) && m.getParameterTypes().length == 1
                        && m.getParameterTypes()[0] == Class.class) {
                    m.setAccessible(true);
                    service = m.invoke(null, c4Class);
                    break;
                }
            }
            if (service == null) throw new NoSuchMethodException("message service");
            Method jj = service.getClass().getMethod("Jj");
            Object storage = jj.invoke(service);
            Method k4 = storage.getClass().getMethod("k4", String.class, long.class);
            Object original = k4.invoke(storage, talker, serverId);
            if (original == null) return;
            Method copy = e9Class.getMethod("z1", e9Class);
            Object notice = copy.invoke(null, original);
            invoke(notice, "setMsgId", long.class, 0L);
            invoke(notice, "n1", long.class, 0L);
            invoke(notice, "m1", long.class, 0L);
            invoke(notice, "a1", long.class, System.currentTimeMillis());
            invoke(notice, "t1", String.class, talker);
            invoke(notice, "Z0", String.class, "对方尝试撤回一条消息（已阻止）");
            invoke(notice, "setType", int.class, 10000);
            invoke(notice, "i1", int.class, 0);
            invoke(notice, "s1", int.class, 3);
            invoke(notice, "c1", int.class, 0);
            Method mb = storage.getClass().getMethod("Mb", e9Class);
            Object result = mb.invoke(storage, notice);
            android.util.Log.i("WxAntiRecall8079", "blocked-revoke notice inserted: " + result);
        } catch (Throwable error) {
            android.util.Log.e("WxAntiRecall8079", "failed to insert blocked-revoke notice", error);
        }
    }

    private static void invoke(Object target, String name, Class<?> type, Object value)
            throws Exception {
        Method method = target.getClass().getMethod(name, type);
        method.invoke(target, value);
    }

    private void installTimeHook(Context context, ClassLoader loader) {
        try {
            Class<?> b0 = Class.forName("com.tencent.mm.ui.chatting.viewitems.b0", false, loader);
            Class<?> h0 = Class.forName("com.tencent.mm.ui.chatting.viewitems.h0", false, loader);
            Class<?> d = Class.forName("el5.d", false, loader);
            Class<?> e9 = Class.forName("com.tencent.mm.storage.e9", false, loader);
            Method bind = b0.getDeclaredMethod("o", h0, d, String.class, e9);
            bind.setAccessible(true);
            hook(bind)
                    .setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .setId("wx-antirecall-8079.message-time")
                    .intercept(chain -> {
                        Object result = chain.proceed();
                        try {
                            Object holder = chain.getArg(0);
                            Object message = chain.getArg(3);
                            updateMessageTime(context, holder, message);
                        } catch (Throwable error) {
                            log(Log.DEBUG, "message time rendering skipped", error);
                        }
                        return result;
                    });
            log(Log.INFO, "installed message time hook: b0.o");
        } catch (Throwable error) {
            log(Log.ERROR, "message time hook installation failed", error);
        }
    }

    private static void updateMessageTime(Context context, Object holder, Object message)
            throws Exception {
        Field field = findField(holder.getClass(), "timeTV");
        if (field == null || !(field.get(holder) instanceof TextView)) return;
        TextView time = (TextView) field.get(holder);
        if (!showTime(context)) {
            time.setVisibility(TextView.GONE);
            return;
        }
        Method getCreateTime = message.getClass().getMethod("getCreateTime");
        long createTime = ((Number) getCreateTime.invoke(message)).longValue();
        if (createTime <= 0) {
            time.setVisibility(TextView.GONE);
            return;
        }
        time.setText(new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                .format(new Date(createTime)));
        time.setTextColor(android.graphics.Color.rgb(86, 45, 174));
        time.setTextSize(14);
        time.setVisibility(TextView.VISIBLE);
    }

    private static boolean showTime(Context context) {
        try {
            android.os.Bundle b = context.getContentResolver().call(
                    android.net.Uri.parse("content://" + SETTINGS_AUTHORITY), "get", null, null);
            return b != null && b.getBoolean("show_time", false);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isEnabled(Context context) {
        try {
            android.os.Bundle b = context.getContentResolver().call(
                    android.net.Uri.parse("content://" + SETTINGS_AUTHORITY), "get", null, null);
            return b == null || b.getBoolean("enabled", true);
        } catch (Throwable ignored) {
            return true;
        }
    }

    private static void setHooked(Context context, boolean hooked) {
        try {
            android.os.Bundle b = new android.os.Bundle();
            b.putBoolean("hooked", hooked);
            context.getContentResolver().call(
                    android.net.Uri.parse("content://" + SETTINGS_AUTHORITY),
                    "set_hooked", null, b);
        } catch (Throwable ignored) {
        }
    }

    private static boolean isIncoming(Object envelope) throws IllegalAccessException {
        if (envelope == null) return false;
        Field field = findField(envelope.getClass(), "b");
        return field != null && field.getBoolean(envelope);
    }

    private static Method findRevokeMethod(Class<?> type, Class<?> envelope)
            throws NoSuchMethodException {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            for (Method candidate : current.getDeclaredMethods()) {
                Class<?>[] p = candidate.getParameterTypes();
                if (candidate.getReturnType() == void.class && p.length == 6
                        && p[0] == String.class && p[1] == long.class
                        && p[2] == envelope && p[3] == String.class
                        && p[4] == String.class && p[5] == String.class) {
                    candidate.setAccessible(true);
                    return candidate;
                }
            }
        }
        throw new NoSuchMethodException("l41.t revoke handler");
    }

    private static Field findField(Class<?> type, String name) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            try {
                Field value = current.getDeclaredField(name);
                value.setAccessible(true);
                return value;
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }

    private void log(int level, String message) {
        log(level, message, (Throwable) null);
    }

    private void log(int level, String message, Throwable error) {
        super.log(level, TAG, message, error);
    }
}
